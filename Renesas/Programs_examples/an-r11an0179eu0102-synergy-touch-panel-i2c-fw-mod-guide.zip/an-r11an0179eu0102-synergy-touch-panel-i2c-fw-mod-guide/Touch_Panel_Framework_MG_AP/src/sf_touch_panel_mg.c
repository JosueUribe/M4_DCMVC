/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/**
 * sf_touch_panel_mg.c
 * Functions to open, start, configure, and close touch panel framework, and process touch events.
 *  Quick tips to customize this example:
 *  1) Configure the period setting of timers using the set_timer_period function
 *  2) Configure the PWM setting of g_timer_gpt_1 (pwm GPT) using the set_timer_pwm function
 *  3) Callbacks can be edited to achieve what the user has in mind. The example toggles an LED in each callback currently.
 *
 *  By default, printf is enabled. To disable printf, comment off the #define SEMI_HOSTING
 */

#include "sf_touch_panel_mg.h"

#include "stdio.h"

/**
 * Pends on a message from internal touch panel. Message contains information regarding the Touch Event and Touch Event coordinates.
 * message->event_b.class_code contains information regarding type of Touch Event - if a Touch event has occured.
 * message->event_b.code indicates of new data is received
 * message->event_type - SF_TOUCH_PANEL_EVENT_UP (Touch lifted), SF_TOUCH_PANEL_EVENT_DOWN (Touch down detected), SF_TOUCH_PANEL_EVENT_HOLD (A Hold event detected), SF_TOUCH_PANEL_EVENT_MOVE (Touch moved coordinates without an UP event)
 **/
void g_sf_touch_panel_event(void)
{
	while(1)
	{
		ssp_err_t        err;

		sf_message_header_t * p_message = NULL;

		err = g_sf_message0.p_api->pend(g_sf_message0.p_ctrl, &touch_panel_thread_message_queue, (sf_message_header_t **) &p_message, TX_WAIT_FOREVER);
		if (err)
		{
			/** TODO: Handle error. */

		}


		switch (p_message->event_b.class_code)
		{
		case SF_MESSAGE_EVENT_CLASS_TOUCH:
		{
			switch (p_message->event_b.code)
			{
			case SF_MESSAGE_EVENT_NEW_DATA:
			{

				const sf_touch_panel_payload_t * p_touch_payload = (sf_touch_panel_payload_t *) p_message;

				switch (p_touch_payload->event_type)
				{
				case SF_TOUCH_PANEL_EVENT_DOWN:
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00 , IOPORT_LEVEL_LOW);
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01 , IOPORT_LEVEL_HIGH);
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02 , IOPORT_LEVEL_HIGH);
#ifdef SEMI_HOSTING
if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
{
	//Debugger is connected
	printf("touch panel down\r\n");
}
#endif
break;

				case SF_TOUCH_PANEL_EVENT_UP:
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00 , IOPORT_LEVEL_HIGH);
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01 , IOPORT_LEVEL_HIGH);
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02 , IOPORT_LEVEL_HIGH);
#ifdef SEMI_HOSTING
if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
{
	//Debugger is connected
	printf("touch panel up\r\n");
}
#endif
				break;

				case SF_TOUCH_PANEL_EVENT_HOLD:
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00 , IOPORT_LEVEL_LOW);
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01 , IOPORT_LEVEL_LOW);
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02 , IOPORT_LEVEL_HIGH);
#ifdef SEMI_HOSTING
if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
{
	//Debugger is connected
	printf("touch panel hold\r\n");
}
#endif
				break;

				case SF_TOUCH_PANEL_EVENT_MOVE:
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00 , IOPORT_LEVEL_LOW);
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01 , IOPORT_LEVEL_HIGH);
					g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02 , IOPORT_LEVEL_LOW);
#ifdef SEMI_HOSTING
if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
{
	//Debugger is connected
	printf("touch panel move\r\n");
}
#endif
				break;

				case SF_TOUCH_PANEL_EVENT_INVALID:
					break;

				default:
					break;
				}

#ifdef SEMI_HOSTING
				if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
				{
					//Debugger is connected
					printf("touch panel x = %d & y = %d\r\n",p_touch_payload->x,p_touch_payload->y);
				}
#endif

			}

			default:
				break;
			}
			break;
		}

		default:
			break;
		}

		/** Message is processed, so release buffer. */
		err = g_sf_message0.p_api->bufferRelease(g_sf_message0.p_ctrl, (sf_message_header_t *) p_message, SF_MESSAGE_RELEASE_OPTION_FORCED_RELEASE);
		if (SSP_SUCCESS != err)
		{
#ifdef SEMI_HOSTING
			if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
			{
				//Debugger is connected
				printf("g_sf_message0.p_api->bufferRelease failed - error = 0x%x\r\n",err);
			}
#endif
			while(1)
			{
			}
		}
	}
}

/** Enable the touch panel function
 *
 */
void g_sf_touch_panel_i2c_framework_enable(void)
{

	//Touch Panel Start
	ssp_err_t err;
	err = g_sf_touch_panel_i2c.p_api->start(g_sf_touch_panel_i2c.p_ctrl);

	if (SSP_SUCCESS != err)
	{
#ifdef SEMI_HOSTING
		if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
		{
			//Debugger is connected
			printf("g_sf_touch_panel_i2c.p_api->start failed - error = 0x%x\r\n",err);
		}
#endif
		while(1)
		{
		}
	}

	//Touch Panel Event
	g_sf_touch_panel_event();

}
