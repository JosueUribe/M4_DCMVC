/* generated common source file - do not edit */
#include "common_data.h"
void g_common_init(void) {
}
