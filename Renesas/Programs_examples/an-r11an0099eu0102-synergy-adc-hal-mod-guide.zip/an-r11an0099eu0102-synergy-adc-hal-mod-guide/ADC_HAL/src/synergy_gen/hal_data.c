/* generated HAL source file - do not edit */
#include "hal_data.h"
#if (1) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_adc0) && !defined(SSP_SUPPRESS_ISR_ADC1)
SSP_VECTOR_DEFINE_CHAN(adc_scan_end_isr, ADC, SCAN_END, 1);
#endif
#endif
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_adc0) && !defined(SSP_SUPPRESS_ISR_ADC1)
SSP_VECTOR_DEFINE_CHAN(adc_scan_end_b_isr, ADC, SCAN_END_B, 1);
#endif
#endif
#ifndef adc_user_callback
void adc_user_callback(adc_callback_args_t * p_args);
#endif
adc_instance_ctrl_t g_adc0_ctrl;
const adc_cfg_t g_adc0_cfg =
{
    .unit                = 1,
    .mode                = ADC_MODE_SINGLE_SCAN,
    .resolution          = ADC_RESOLUTION_12_BIT,
    .alignment           = ADC_ALIGNMENT_RIGHT,
    .add_average_count   = ADC_ADD_OFF,
    .clearing            = ADC_CLEAR_AFTER_READ_ON,
    .trigger             = ADC_TRIGGER_SOFTWARE,
    .trigger_group_b     = ADC_TRIGGER_SYNC_ELC,
    .p_callback          = adc_user_callback,
    .p_context           = &g_adc0,
    .scan_end_ipl        = (1),
    .scan_end_b_ipl      = (BSP_IRQ_DISABLED),
};
const adc_channel_cfg_t g_adc0_channel_cfg =
{
    .scan_mask           = (uint32_t)(((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)ADC_MASK_TEMPERATURE) | (0)),
	/** Group B channel mask is right shifted by 32 at the end to form the proper mask */
	.scan_mask_group_b   = (uint32_t)((((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)0) | ((uint64_t)ADC_MASK_TEMPERATURE) | (0)) >> 32),
	.priority_group_a    = ADC_GROUP_A_PRIORITY_OFF,
	.add_mask            = (uint32_t)((0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0)| (0) | (0)| (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0)),
	.sample_hold_mask    = (uint32_t)((0) | (0) | (0)),
	.sample_hold_states  = 24,
};
/* Instance structure to use this module. */
const adc_instance_t g_adc0 = 
{
	.p_ctrl 	   = &g_adc0_ctrl,
	.p_cfg  	   = &g_adc0_cfg,
	.p_channel_cfg = &g_adc0_channel_cfg,
	.p_api  	   = &g_adc_on_adc
};
const ioport_instance_t g_ioport = 
        {
            .p_api = &g_ioport_on_ioport,
            .p_cfg = NULL
        };
/* Instance structure to use this module. */
const fmi_instance_t g_fmi = 
{
    .p_api         = &g_fmi_on_fmi
};
const cgc_instance_t g_cgc = {
            .p_api = &g_cgc_on_cgc,
            .p_cfg = NULL
        };
const elc_instance_t g_elc = {
            .p_api = &g_elc_on_elc,
            .p_cfg = NULL
        };
void g_hal_init(void) {
g_common_init();
}
