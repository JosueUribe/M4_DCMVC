#include "hal_data.h"
#include <stdio.h>

#define UNUSED(x) (void)(x)
void adc_hal_demo(void);

adc_data_size_t adc_data;
bool flag = false;  //flag to notify the ADC result is updated
void adc_hal_demo(void)
{
    ssp_err_t status;
    // Initialize ADC Driver
    status = g_adc.p_api->open(g_adc.p_ctrl, g_adc.p_cfg);
    if(status != SSP_SUCCESS) while (1);

    //Configure ADC Channel
    status =  g_adc.p_api->scanCfg(g_adc.p_ctrl, g_adc.p_channel_cfg);
    if(status != SSP_SUCCESS) while (1);
    while (1)
    {
        //Start the ADC scan
        status = g_adc.p_api->scanStart(g_adc.p_ctrl);
        if(status == SSP_SUCCESS)
        {
        //Check scan status
        status = g_adc.p_api->scanStatusGet(g_adc.p_ctrl);
        }

        if(SSP_SUCCESS == status)
        {
            // Stop the scan
            g_adc.p_api->scanStop(g_adc.p_ctrl);
        }

        if(flag==true)
        {
            printf("Internal Temperature Sensor value measured by ADC: %d\n",adc_data);
            flag = false;
        }
    }
    //Close the channel
    g_adc.p_api->close(g_adc.p_ctrl);
}

void adc_user_callback(adc_callback_args_t * p_args)
{
    UNUSED(p_args);
    //Read the result
    g_adc.p_api->read(g_adc.p_ctrl, ADC_REG_TEMPERATURE, &adc_data);
    flag = true;
}
