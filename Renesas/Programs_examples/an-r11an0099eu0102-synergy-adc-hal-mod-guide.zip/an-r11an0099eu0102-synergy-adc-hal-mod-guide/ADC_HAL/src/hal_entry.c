/* HAL-only entry function */
#include "hal_data.h"
#include <stdio.h>

#if   defined(__GNUC__)                 /* GCC Compiler */
extern void initialise_monitor_handles(void);
#endif

extern void adc_hal_demo(void);

void hal_entry(void)
{
    #if   defined(__GNUC__)                 /* GCC Compiler */
    initialise_monitor_handles();
    #endif

    adc_hal_demo();
}
