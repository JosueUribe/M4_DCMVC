/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File name   : external_irq_fw_led_blinking.c
* Description : This short example demonstrates usage of External IRQ Framework module which is a generic API for
*               applications using the external pin interrupts with the ThreadX RTOS.
*               After starting this application on the target device the user LEDs start to blink. Pushing the user
*               buttons causes a change of delay which is used to control blinking frequency.
***********************************************************************************************************************/

/***********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*           28.07.2017 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes
***********************************************************************************************************************/
#include "external_irq_fw_led_blinking.h"
#include "external_irq_fw_thread.h"

/***********************************************************************************************************************
 * External IRQ FW LEDs blinking function.
 * It is responsible for LEDs blinking and for changing the blinking frequency in case a user button was pushed.
***********************************************************************************************************************/
void external_irq_fw_led_blinking(void)
{
    /* Use semihosting to send debug output to the Renesas Debug Virtual Console */
#ifdef SEMI_HOSTING
#ifdef __GNUC__
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        /* Initialize the debug output utility */
        initialise_monitor_handles();
    }
#endif
#endif

    /* LED blinking interval time variable */
    uint32_t delay = INITIAL_DELAY;

    /* LED type structure */
    bsp_leds_t leds;

    /* LED state variable */
    ioport_level_t level = IOPORT_LEVEL_HIGH;

    /* Function return value variable */
    ssp_err_t status;

    /* Get LEDs information for this board */
    R_BSP_LedsGet(&leds);

    /* Check if board has LEDs */
    if (0u == leds.led_count)
    {
        /* Use semihosting to send debug output to the Renesas Debug Virtual Console */
#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            /* Print error notification in the Renesas Debug Virtual Console */
            printf("Error: There are no LEDs on this board\n");
        }
#endif
        tx_thread_sleep(TX_WAIT_FOREVER);
    }

    /* Open External IRQ for user button S4 */
    status = g_sf_external_irq_button_S4.p_api->open(g_sf_external_irq_button_S4.p_ctrl,
                                                     g_sf_external_irq_button_S4.p_cfg);
    if (SSP_SUCCESS != status)
    {
        /* Use semihosting to send debug output to the Renesas Debug Virtual Console */
#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            /* Print error notification in the Renesas Debug Virtual Console */
            printf("Error: Failed to open External IRQ\n");
        }
#endif
        tx_thread_sleep(TX_WAIT_FOREVER);
    }

    /* Open External IRQ for user button S5 */
    status = g_sf_external_irq_button_S5.p_api->open(g_sf_external_irq_button_S5.p_ctrl,
                                                     g_sf_external_irq_button_S5.p_cfg);
    if (SSP_SUCCESS != status)
    {
        /* Use semihosting to send debug output to the Renesas Debug Virtual Console */
#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            /* Print error notification in the Renesas Debug Virtual Console */
            printf("Error: Failed to open External IRQ\n");
        }
#endif
        tx_thread_sleep(TX_WAIT_FOREVER);
    }

    /* The main while loop */
    while (1)
    {
        /* Check if user button S4 was pressed */
        status = g_sf_external_irq_button_S4.p_api->wait(g_sf_external_irq_button_S4.p_ctrl, TX_NO_WAIT);

        /* Increase blinking frequency (decrease delay) if user button S4 was pressed */
        if (SSP_SUCCESS == status)
        {
            /* Prevents delay to be less than MIN_DELAY */
            if ((MIN_DELAY * DELAY_CHANGE_FACTOR) <= delay)
            {
                delay = delay / DELAY_CHANGE_FACTOR;
            }
            /* Guarantees that delay can reach MIN_DELAY */
            else
            {
                delay = MIN_DELAY;
            }
        }

        /* Check if user button S5 was pressed */
        status = g_sf_external_irq_button_S5.p_api->wait(g_sf_external_irq_button_S5.p_ctrl, TX_NO_WAIT);

        /* Decrease blinking frequency (increase delay) if user button S5 was pressed */
        if (SSP_SUCCESS == status)
        {
            /* In case of delay dropped to 0 (what should not happen), just set it to MIN_DELAY */
            if (0u == delay)
            {
                delay = MIN_DELAY;
            }
            /* Prevents delay to be more than MAX_DELAY */
            else if ((MAX_DELAY / DELAY_CHANGE_FACTOR) >= delay)
            {
                delay = delay * DELAY_CHANGE_FACTOR;
            }
            /* Guarantees that delay can reach MAX_DELAY */
            else
            {
                delay = MAX_DELAY;
            }
        }

        /* Determine the next state of the LEDs based on the previous state */
        if (IOPORT_LEVEL_LOW == level)
        {
            level = IOPORT_LEVEL_HIGH;
        }
        else
        {
            level = IOPORT_LEVEL_LOW;
        }

        /* Toggle all board LEDs on or off */
        for (uint16_t i = 0; i < leds.led_count; i++)
        {
            g_ioport.p_api->pinWrite(leds.p_leds[i], level);
        }

        /* Wait for a specified time */
        tx_thread_sleep(delay);

    } /* End of the main while loop */

} /* End of function external_irq_fw_led_blinking */
